# Интернет-магазин на основе framework Django

Интернет магазин разработан в рамках прохождения факультета Python-разработки, портал GeekBrains, на курсе `Framework Django`.

## Стек

* Python>3.5
* Django<3.0
* VSCode
* SQLite3

## Лицензия

MIT

