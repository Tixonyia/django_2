from django.apps import AppConfig


class AdminappConfig(AppConfig):
    name = "adminapp"
