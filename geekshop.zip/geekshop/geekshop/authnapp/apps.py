from django.apps import AppConfig


class AuthnappConfig(AppConfig):
    name = "authnapp"
